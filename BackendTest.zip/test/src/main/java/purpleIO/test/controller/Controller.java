package purpleIO.test.controller;

import org.springframework.web.bind.annotation.*;

@org.springframework.stereotype.Controller
public class Controller {

    @GetMapping("/search")
    public String search() {
        return "home";
    }

    @PostMapping("/search")
    public String result() {
        return "home";
    }

}
